#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

#define BUFFER_SIZE 1024  /* 每次读/写缓存大小，影响运行效率 */

// main函数接收命令行参数
// argc: 参数总数
// argv: 参数值数组 (argv[0]是程序名, argv[1]接收源文件参数，argv[2]接收目标文件)
int main(int argc, char *argv[])
{
    int src_file, dest_file;
    unsigned char buff[BUFFER_SIZE];
    int real_read_len;
    
    /* 检查命令行参数数量是否正确 */
    if (argc != 3)
    {
        // 将该程序的正确用法打印出来，使用户知道如何正确使用
        fprintf(stderr, "Usage: %s <source_file> <destination_file>\n", argv[0]);
        exit(1);
    }

    /* * argv[1] 是源文件名
     * argv[2] 是目标文件名
     */

    /* 以只读方式打开源文件  */
    src_file = open(argv[1], O_RDONLY);
    if (src_file < 0)
    {
        // perror会打印用户提供的信息，后跟一个冒号和一个系统错误信息
        perror("Error opening source file");
        exit(1);
    }

    /* 以只写方式打开目标文件，若此文件不存在则创建该文件, 访问权限值为644 */
    dest_file = open(argv[2], O_WRONLY|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR|
    S_IRGRP|S_IROTH);
    if (dest_file < 0)//打开文件失败
    {
        perror("Error opening destination file");
        close(src_file); // 在退出前关闭已成功打开的文件
        exit(1);
    }


    /* 读取源文件的数据并写到目标文件中 */
    while ((real_read_len = read(src_file, buff, sizeof(buff))) > 0)
    {
         
         if (write(dest_file, buff, real_read_len) != real_read_len) {
            perror("Error writing to destination file");
            close(src_file);
            close(dest_file);
            exit(1);
         }
    }

    if (real_read_len < 0) {
        perror("Error reading from source file");
        close(src_file);
        close(dest_file);
        exit(1);
    }


    printf("File copied successfully.\n");

    /* 关闭文件 */
    close(dest_file);
    close(src_file);
    
    return 0;
}

